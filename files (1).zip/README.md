# Superstore Sales Analysis (Excel + SQL)

An analysis of four years of US retail sales (2015 to 2018). I cleaned the data with Python, built an Excel dashboard, and answered business questions with SQL.

**Author:** Mohamed Hassan Osman, Management Information Systems student

![Excel dashboard](docs/dashboard.png)

## What I wanted to find out

1. How much does the store sell, and is it growing?
2. Which regions, categories, products and states bring in the most sales?
3. Are there seasonal patterns I can plan around?

## Key findings

- Total sales were **$2.26 million** across 4,922 orders from 793 customers (about $459 per order).
- Sales dipped 4.3% in 2016, then grew **30.6% in 2017** and **20.3% in 2018**.
- Sales are very seasonal. **November and December bring about 30% of all sales**, September is the next strongest month, and January and February are the weakest.
- The **West** region is the largest (31.4% of sales) and the **South** is the smallest (17.2%).
- **Technology** is the top category (36.6%), but Furniture and Office Supplies are close behind. **Phones** and **Chairs** are the best sub-categories.
- **California and New York** together make up about a third of all sales.
- One product, the Canon imageCLASS 2200 Advanced Copier, sold more than twice as much as any other product.

## Project structure

```
superstore-analysis/
├── data/
│   ├── Superstore_Sales_Dataset_raw.csv     original file
│   └── Superstore_Sales_Dataset_clean.csv   after cleaning
├── project1_excel/
│   ├── Superstore_Sales_Dashboard.xlsx      dashboard, analysis tables, key findings
│   └── build_workbook.py                    script that builds the workbook
├── project2_sql/
│   ├── clean_data.py                        cleans the CSV and builds the database
│   ├── superstore.db                        SQLite database
│   ├── queries.sql                          10 queries with comments
│   └── results.md                           the output of every query
└── docs/dashboard.png
```

## Project 1: Excel dashboard

The workbook has four sheets:

- **Dashboard**: four headline numbers (total sales, orders, customers, average order value) and seven charts.
- **Key Findings**: the main takeaways and recommendations in plain English.
- **Analysis**: summary tables by region, category, sub-category, segment, state, product, year and month. Every number is a `SUMIFS` formula that reads from the Data sheet, so the tables update if the data changes.
- **Data**: the cleaned dataset (9,800 rows).

## Project 2: SQL analysis

I loaded the cleaned data into SQLite and wrote 10 queries, from simple totals to a year-over-year growth calculation with a window function (`LAG`). The questions are:

| # | Question |
|---|----------|
| 1 | Total sales, orders, customers and average order value |
| 2 | Sales by region |
| 3 | Sales by category and sub-category |
| 4 | Top 10 products |
| 5 | Yearly sales and year-over-year growth |
| 6 | Sales by calendar month (seasonality) |
| 7 | Top 10 states |
| 8 | Top 10 customers |
| 9 | Sales and average order value by customer segment |
| 10 | Shipping mode and delivery time |

You can see every result in [`project2_sql/results.md`](project2_sql/results.md).

**To run it yourself:** open `project2_sql/superstore.db` in [DB Browser for SQLite](https://sqlitebrowser.org/), go to the *Execute SQL* tab, and paste in any query from `queries.sql`. To rebuild the database from scratch, run `python project2_sql/clean_data.py` from the project folder (needs Python and pandas).

## Data cleaning steps

- Converted the order and ship dates to real dates (the file uses day/month/year).
- Found 11 rows with a missing postal code, all in Burlington, Vermont. I filled them with that city's ZIP code (05401).
- Stored postal codes as 5-digit text so leading zeros are not lost.
- Checked for duplicate rows and missing values (none left after the fix above).
- Added helper columns: Year, Month, Ship Days, and flags that mark the first row of each order and customer, which makes counting orders and customers easy in Excel.

## Limits of this analysis

- The dataset has **no profit, discount or quantity columns**, so I could only analyze sales. High sales do not always mean high profit, so the next step would be to repeat this with a dataset that includes profit.
- The data is fictional and meant for learning, so the findings are not about a real company.

## Data source

The "Superstore Sales Dataset" is a public practice dataset that is available on Kaggle. Please check the dataset page for its terms before reusing it.

## Tools

Excel, SQL (SQLite), Python (pandas, openpyxl), Git and GitHub
