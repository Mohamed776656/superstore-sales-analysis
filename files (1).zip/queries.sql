-- Superstore Sales Analysis (SQLite)
-- Table: orders (one row per product line in an order, 9,800 rows, 2015-2018)
-- Note: this dataset has no profit, discount or quantity columns, so every query is about SALES.

-- Q1. Big picture: total sales, orders, customers and average order value
SELECT ROUND(SUM(sales), 2)                          AS total_sales,
       COUNT(DISTINCT order_id)                      AS total_orders,
       COUNT(DISTINCT customer_id)                   AS total_customers,
       ROUND(SUM(sales) / COUNT(DISTINCT order_id), 2) AS avg_order_value
FROM orders;

-- Q2. Sales by region (with share of total)
SELECT region,
       ROUND(SUM(sales), 2) AS total_sales,
       ROUND(100.0 * SUM(sales) / (SELECT SUM(sales) FROM orders), 1) AS pct_of_total
FROM orders
GROUP BY region
ORDER BY total_sales DESC;

-- Q3. Sales by category and sub-category
SELECT category, sub_category,
       ROUND(SUM(sales), 2) AS total_sales
FROM orders
GROUP BY category, sub_category
ORDER BY total_sales DESC;

-- Q4. Top 10 products by sales
SELECT product_name,
       category,
       ROUND(SUM(sales), 2) AS total_sales
FROM orders
GROUP BY product_name, category
ORDER BY total_sales DESC
LIMIT 10;

-- Q5. Yearly sales and year-over-year growth (LAG looks at the previous year's row)
WITH yearly AS (
    SELECT CAST(strftime('%Y', order_date) AS INTEGER) AS year,
           SUM(sales) AS total_sales
    FROM orders
    GROUP BY year
)
SELECT year,
       ROUND(total_sales, 2) AS total_sales,
       ROUND(100.0 * (total_sales - LAG(total_sales) OVER (ORDER BY year))
             / LAG(total_sales) OVER (ORDER BY year), 1) AS yoy_growth_pct
FROM yearly
ORDER BY year;

-- Q6. Seasonality: sales by calendar month, all years combined
SELECT CAST(strftime('%m', order_date) AS INTEGER) AS month,
       ROUND(SUM(sales), 2) AS total_sales
FROM orders
GROUP BY month
ORDER BY month;

-- Q7. Top 10 states by sales
SELECT state,
       ROUND(SUM(sales), 2) AS total_sales,
       ROUND(100.0 * SUM(sales) / (SELECT SUM(sales) FROM orders), 1) AS pct_of_total
FROM orders
GROUP BY state
ORDER BY total_sales DESC
LIMIT 10;

-- Q8. Top 10 customers by total spend
SELECT customer_name,
       segment,
       COUNT(DISTINCT order_id) AS orders_placed,
       ROUND(SUM(sales), 2)     AS total_spent
FROM orders
GROUP BY customer_id, customer_name, segment
ORDER BY total_spent DESC
LIMIT 10;

-- Q9. Sales and average order value by customer segment
SELECT segment,
       ROUND(SUM(sales), 2) AS total_sales,
       COUNT(DISTINCT order_id) AS orders,
       ROUND(SUM(sales) / COUNT(DISTINCT order_id), 2) AS avg_order_value
FROM orders
GROUP BY segment
ORDER BY total_sales DESC;

-- Q10. Shipping: how many orders per ship mode and how long delivery takes
SELECT ship_mode,
       COUNT(DISTINCT order_id) AS orders,
       ROUND(AVG(ship_days), 1) AS avg_days_to_ship
FROM orders
GROUP BY ship_mode
ORDER BY orders DESC;
